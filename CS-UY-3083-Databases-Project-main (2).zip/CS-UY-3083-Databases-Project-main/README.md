# CS-UY-3083-Databases-Project

To Do:
  1. Html Pages: <br>
      (1) Home Page - Anwar <br>
      (2) Customer Login Page - Anwar <br>
      (4) Airline Staff Login Page - Anwar <br>
      (3) Logout Page <br>
      (4) Register Page <br>
      (5) Customer Register Page + Home - Monte <br>
      (6) Airline Staff Register Page + Home - Christy <br>
      (7) Future Flights - Anwar <br>

Meeting times:
Tuesdays/Thursday 3:20 PM
